🌌 FrostByte - Écosystème d'Exploration Spatiale

📦 PACKAGE DE DÉPLOIEMENT NETLIFY

✅ CONTENU :
- index.html : Page d'accueil interactive avec animations spatiales
- game/ : Jeu Cosmo d'exploration spatiale (10 niveaux)
- chatbot_test.html : Interface chatbot IA multilingue
- _redirects : Configuration navigation Netlify
- netlify.toml : Paramètres de déploiement

🚀 DÉPLOIEMENT :
1. Allez sur https://app.netlify.com/drop
2. Faites glisser ce fichier ZIP
3. Votre site sera live en 30 secondes !

🎯 URLS ACCESSIBLES APRÈS DÉPLOIEMENT :
- [URL]/ → Page d'accueil FrostByte
- [URL]/game/ → Jeu Cosmo
- [URL]/chatbot → Chatbot IA

🌟 Développé avec passion pour l'exploration spatiale !

Repository GitHub : https://github.com/Promis229/FrostByte
